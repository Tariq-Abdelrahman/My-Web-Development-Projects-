<?php

require 'config/constants.php';

//Destroy all sessions and redirect the user to homepage
session_destroy();
header('location:' . ROOT_URL);
die();
?>