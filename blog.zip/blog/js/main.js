const navItems = document.querySelector('.nav__items');
const openNavBtn = document.querySelector('#open__nav-btn');
const closeNavBtn = document.querySelector('#close__nav-btn');

const openNav = () => {
    navItems.style.display = 'flex'; 
    openNavBtn.style.display = 'none'; 
    closeNavBtn.style.display = 'inline-block'; 
}

const closeNav = () => {
    navItems.style.display = 'none'; 
    openNavBtn.style.display = 'inline-block'; 
    closeNavBtn.style.display = 'none'; 
}

openNavBtn.addEventListener('click', openNav);
closeNavBtn.addEventListener('click', closeNav);



const sidebar = document.querySelector('aside');
const showSidearBtn = document.querySelector('#show__sidebar-btn');
const hideSidearBtn = document.querySelector('#hide__sidebar-btn');

// Shows Sidebar On Small Devices
const showSidebar = () => {
    sidebar.style.left = '0';
    showSidearBtn.style.display = 'none';
    hideSidearBtn.style.display = 'inline-block';
}

// Hides Sidebar On Small Devices
const hideSidebar = () => {
    sidebar.style.left = '-100%';
    showSidearBtn.style.display = 'inline-block';
    hideSidearBtn.style.display = 'none';
}

showSidearBtn.addEventListener('click', showSidebar);
hideSidearBtn.addEventListener('click', hideSidebar);

